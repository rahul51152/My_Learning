#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	char a[15]="rahul chauhan"; //rahul
	char b[10]="hul"; //mehul
	ispresent(a,b); //ra,esjS
}
