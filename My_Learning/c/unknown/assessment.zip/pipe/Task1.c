#include"file.h"
#include<fcntl.h>

void *Task1 (void *i){
	char buf[3];
	int *fp;
	extern p[1];
	fp=open("input.txt",O_RDWR|0666);
	while(read(fp,buf,3)>0){
		write(p[1],buf,3);
	}
	close(fp);
}

