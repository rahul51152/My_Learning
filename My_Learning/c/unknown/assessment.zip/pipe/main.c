#include<stdio.h>
#include<pthread.h>
#include<fcntl.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/ipc.h>
#include<sys/types.h>
#include"file.h"
int main(){
	int p[2];
	pipe(p);
	pthread_t thread1, thread2;
	pthread_create(&thread1,NULL,Task1,NULL);
	pthread_create(&thread2,NULL,Task2,NULL);
	pthread_join(&thread1,NULL);
	pthread_join(&thread2,NULL);
	return 0;
}




