#include<fcntl.h>
#include"file.h"

void *Task2(void*i){
	extern p[0];
	int *fd1;
	char buf[3];
	while(read(p[0],buf,3)>0){


