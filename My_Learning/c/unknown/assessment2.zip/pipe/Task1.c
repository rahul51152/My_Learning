#include"file.h"
#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>

extern int p[1];
void *Task1 (void *i){
	char buf[8];
	FILE* fp;
	fp=fopen("input.txt","r");
	while(fgets(buf,sizeof(buf),fp)){
		write(p[1],buf,sizeof(buf));
	}
	fclose(fp);
}

