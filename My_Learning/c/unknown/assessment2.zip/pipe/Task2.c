#include<stdio.h>
#include<fcntl.h>
#include"file.h"
#include<string.h>
#include<unistd.h>
void *Task2(void*i){
	extern int p[0];
	char buf[8];
	FILE* fd;	
	while(read(p[0],buf,8)>0){
		printf("%s\n",buf);
		int a=pattern(buf);
	//	printf("%d\n",a);
		int r=calc(a,buf);
		printf("result = %d\n",r);
		sleep(1);
		fd=fopen("output.txt","a");
		fprintf(fd,"%d\n",r);
		fclose(fd);

	}

}




