#include<stdio.h>
#include<string.h>
#include"file.h"

int pattern(char *s){
	for(int i=0; i<strlen(s);i++){
		if(s[i]=='+'){
			return 1;
		}
		if(s[i]=='-'){
			return 2;
		}
		if(s[i]=='*'){
			return 3;
		}
		if(s[i]=='/'){
			return 4;
		}
	}
}

int calc(int a,char *s){
	int i=0,j=0;
	char str1[3];
	char str2[3];
	long sum;
	switch(a){
		case 1: while(s[i]!='+'){
				str1[i]=s[i];
				i++;
			}
			i++;
			while(s[i]!='\0'){
				str2[j]=s[i];
				j++;
				i++;
			}
			sum = atoi(str1)+atoi(str2);
			return sum;
		
		case 2: while(s[i]!='-'){
				str1[i]=s[i];
				i++;
			}
			i++;
			while(s[i]!='\0'){
				str2[j]=s[i];
				j++;
				i++;
			}
			sum = atoi(str1)-atoi(str2);
			return sum;
			
		
		case 3 : while(s[i]!='*'){
				str1[i]=s[i];
				i++;
			}
			i++;
			while(s[i]!='\0'){
				str2[j]=s[i];
				j++;
				i++;
			}
			sum = atoi(str1)*atoi(str2);
			return sum;

		case 4 : while(s[i]!='/'){
				str1[i]=s[i];
				i++;
			}
			i++;
			while(s[i]!='\0'){
				str2[j]=s[i];
				j++;
				i++;
			}
			sum = atoi(str1)/atoi(str2);
			return sum;
	}
}





