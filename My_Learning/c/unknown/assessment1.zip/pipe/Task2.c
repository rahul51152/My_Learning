#include<stdio.h>
#include<fcntl.h>
#include"file.h"

void *Task2(void*i){
	extern int p[0];
	int fd1;
	char buf[7];
	extern lock;
	pthread_mutex_lock(&lock);
	while(read(p[0],buf,7)>0){
		printf("%s",buf);
		pthread_mutex_unlock(&lock);
	}
	close(fd1);
}




