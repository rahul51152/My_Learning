#include"file.h"
#include<fcntl.h>
#include<stdio.h>
#include<string.h>

void *Task1 (void *i){
	char buf[7];
	int fp;
	int a;
	extern int p[1];
	extern lock;
	fp=open("input.txt",O_RDONLY);
	pthread_mutex_lock(&lock);
	while(read(fp,buf,7)>0){
		write(p[1],buf,strlen(buf));
		pthread_mutex_unlock(&lock);
	}
	close(fp);
}

