void *Task1(void *i);
void *Task2(void *i);
int pattern(char *s);
